const generate = document.getElementById('generate');
const zip = document.getElementById('zip');
const feelings = document.getElementById('feelings');
const content = document.getElementById('content');
const temp = document.getElementById('temp');
const d = new Date();
const date = d.toDateString();
const example = 'http://api.openweathermap.org/data/2.5/weather?zip='
const key = '&appid=12f4a4b0d0d04168478054c65966c9e8'

generate.addEventListener('click', (event) => {
event.preventDefault()
const baseUrl = baseUrl +`${zip.value}${key}`
GamepadHapticActuator(madeURL)
});

const getData = async(url) => {
    try{
        const result = await fetch(url);
    const data = await result.json();
console.log(data);
return data;} 
    catch(e){
        console.log(e);
    }
}